package Servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Aplicacion {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		int puertoEscucha = 22222;
		try {
			ServerSocket socketServidor = new ServerSocket(puertoEscucha);
			System.out.println("Servidor esta escuchando");
			Socket socketCleinte = socketServidor.accept();
			System.out.println("Servidor ha recibido al cliente");
			GestionAplicacion gestion = null;
			gestion = new GestionAplicacion(socketCleinte);
			gestion.start();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
