package Servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

public class GestionAplicacion extends Thread {
	BufferedReader leer;
	PrintWriter escribir;
	Socket socketCliente;

	public GestionAplicacion() {
		// TODO Auto-generated constructor stub
	}

	GestionAplicacion(Socket s) {
		try {
			this.socketCliente = s;
			escribir = new PrintWriter(socketCliente.getOutputStream(), true);
			leer = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		boolean salir = false;
		while (salir == false) {
			String linea = "";
			try {
				while ((linea = leer.readLine()) != null) {

					if (linea.equalsIgnoreCase("opcion1")) {

					}
					if (linea.equalsIgnoreCase("TodasLasCitas")) {

					}
					if (linea.equalsIgnoreCase("fin")) {
						salir = true;
					}
					escribir.println("Fin de respuesta");
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (leer != null)
						leer.close();
					if (escribir != null)
						escribir.close();
					if (socketCliente != null)
						socketCliente.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
