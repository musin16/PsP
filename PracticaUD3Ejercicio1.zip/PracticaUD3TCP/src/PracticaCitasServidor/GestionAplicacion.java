package PracticaCitasServidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

public class GestionAplicacion extends Thread {
	BufferedReader leer;
	PrintWriter escribir;
	Socket socketCliente;

	public GestionAplicacion(Socket s) {
		try {
			this.socketCliente = s;
			escribir = new PrintWriter(socketCliente.getOutputStream(), true);
			leer = new BufferedReader(new InputStreamReader(socketCliente.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		boolean salir = false;
		while (!salir) {
			try {
				String linea;
				while ((linea = leer.readLine()) != null) {
					String[] vpartes = linea.split(";");
					ArrayList<Cita> c = new ArrayList<>();
					// Verificar si vpartes[1] es un número
					if (vpartes.length == 3 && esNumero(vpartes[1])) {
						for (Cita cita : Aplicacion.citas) {
							if ((cita.getAutor().toLowerCase().contains(vpartes[0].toLowerCase()) || 
									cita.getCita().toLowerCase().contains(vpartes[0].toLowerCase())) && 
									Integer.parseInt(vpartes[1]) == cita.getIdioma()) {
								c.add(cita);
							}
						}
						if (vpartes[2].equalsIgnoreCase("todas")) {
							for (Cita cita : c) {
								escribir.println((cita.toString()));
							}
						} else if (vpartes[2].equalsIgnoreCase("una") && !c.isEmpty()) {
							Random r = new Random();
							escribir.println(c.get(r.nextInt(c.size())).toString());
						}
					} else {
						// Cuando el cliente no proporciona tres partes separadas por ";"
						escribir.println(
								"Error: La solicitud debe contener tres partes separadas por ';' (termino;idioma;tipoRespuesta)");
					}
					if (linea.equalsIgnoreCase("TodasLasCitas")) {
						for (Cita cita : Aplicacion.citas) {
							escribir.println((cita.toString()));
						}
					}
					if (linea.equalsIgnoreCase("fin")) {
						salir = true;
					}
					escribir.println("Fin de respuesta");
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (leer != null)
						leer.close();
					if (escribir != null)
						escribir.close();
					if (socketCliente != null)
						socketCliente.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private boolean esNumero(String contenido) {
		try {
			Integer.parseInt(contenido);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}
}
