package PracticaCitasServidor;

public class Cita {
	private String autor;
	private String cita;
	private int idioma;

	public Cita() {
	}

	public Cita(String autor, String cita, int idioma) {
		this.autor = autor;
		this.cita = cita;
		this.idioma = idioma;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getCita() {
		return cita;
	}

	public void setCita(String cita) {
		this.cita = cita;
	}

	public int getIdioma() {
		return idioma;
	}

	public void setIdioma(int idioma) {
		this.idioma = idioma;
	}

	@Override
	public String toString() {
		return autor + ";" + cita + ";" + idioma;
	}

}
