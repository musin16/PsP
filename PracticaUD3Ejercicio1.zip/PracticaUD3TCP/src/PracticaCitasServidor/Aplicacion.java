package PracticaCitasServidor;

import java.io.*;
import java.net.*;
import java.util.*;

public class Aplicacion {
    public static Scanner sc = new Scanner(System.in);
    public static ArrayList<Cita> citas = new ArrayList<>();

    public static void main(String[] args) {
        // Agregando las citas
        agregarCitas();

     
        int puertoEscucha = 22222;
        try (ServerSocket socketServidor = new ServerSocket(puertoEscucha)) {
            System.out.println("Servidor está escuchando");
            // Esperar conexiones de clientes
            while (true) {
                Socket socketCliente = socketServidor.accept();
                System.out.println("Servidor ha recibido al cliente");
                new GestionAplicacion(socketCliente).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Agregando las citas al arrayList Cita
    private static void agregarCitas() {
        citas.add(new Cita("Groucho Marx", "¿A quién va usted a creer, a mí o a sus propios ojos?", 1));
        citas.add(new Cita("Groucho Marx", "No puedo decir que no estoy en desacuerdo contigo", 1));
        citas.add(new Cita("Groucho Marx",
                "Those are my principles, and if you don't like them... well, I have others.", 2));
        citas.add(new Cita("Groucho Marx", "I refuse to join any club that would have me as a member.", 2));
        citas.add(new Cita("Benjamin Franklin", "Well done is better than well said", 2));
        citas.add(new Cita("Mark Twain", "Don't dream your life, live your dream", 2));
        citas.add(new Cita("", "The harder I work, the luckier I get", 2));
        citas.add(new Cita("Octavio Paz", "Aprender a sonreír es aprender a ser libres", 1));
        citas.add(new Cita("Hemingway", "Se necesitan dos años para aprender a hablar y sesenta para aprender a callar", 1));
        citas.add(new Cita("Che Guevara", "Seamos realistas y hagamos lo imposible.", 1));
    }
}
