package PracticaCitasCliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Aplicacion {
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		int puertoEscucha = 22222;
		String direccionServidor = "localhost";
		Socket socket = null;
		BufferedReader leer = null;
		PrintWriter escribir = null;
		try {

			socket = new Socket(direccionServidor, puertoEscucha);
			leer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			escribir = new PrintWriter(socket.getOutputStream(), true);
			System.out.println("Servidor te ha recibido cliente");
			boolean salir = false;
			String opcion = "";
			String mensaje = "";
			while (salir == false) {
				System.out.println("[1] Mostrar cita aleatoria");
				System.out.println("[2] Mostrar conjunto de citas");
				System.out.println("[3] Salir");
				opcion = sc.nextLine();
				if (opcion.equalsIgnoreCase("1")) {
					System.out.println("Introduce el termino de busqueda: ");
					String termino = sc.nextLine() + ";";
					System.out.println("Introduce el codigo del idioma: (1)Español/(2)Inglés");
					String codigo = sc.nextLine() + ";";
					System.out.println("Tipo de respuesta: (1)una / (2)todas");
					String tipoRespuesta = sc.nextLine();
					if (tipoRespuesta.equalsIgnoreCase("1")) {
						tipoRespuesta = "una";
					} else if (tipoRespuesta.equalsIgnoreCase("2")) {
						tipoRespuesta = "todas";
					}
					mensaje = termino + codigo + tipoRespuesta;
					mandarSolicitudDeCita(mensaje, socket, leer, escribir, true);
				} else if (opcion.equalsIgnoreCase("2")) {
					mensaje = "TodasLasCitas";
					mandarSolicitudDeCita(mensaje, socket, leer, escribir, true);
				} else if (opcion.equalsIgnoreCase("3")) {
					mensaje = "fin";
					mandarSolicitudDeCita(mensaje, socket, leer, escribir, false);
					salir = true;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (escribir != null) {
					escribir.close();
				}
				if (leer != null) {
					leer.close();
				}
				if (socket != null) {
					socket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	private static void mandarSolicitudDeCita(String mensaje, Socket socket, BufferedReader leer, PrintWriter escribir,
			boolean respuesta) {
		try {
			escribir.println(mensaje);
			if (respuesta) {
				String linea = "";
				while ((linea = leer.readLine()) != null) {
					if (linea.equalsIgnoreCase("Fin de respuesta")) {
						break;
					} else {
						String[] vpartes = linea.split(";");
						if (vpartes.length >= 2) {
							System.out.println(vpartes[1] + "(" + vpartes[0] + ")");
						} else if (vpartes.length == 1) {
							System.out.println(vpartes[0]);
						}
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
