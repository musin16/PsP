package PracticaCitasCliente;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class ClienteUDP {
    private static final String SERVIDOR_IP = "localhost";
    private static final int PUERTO = 22222;
    private static final int TAM_BUFFER = 1024;

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in);
                DatagramSocket socketCliente = new DatagramSocket()) {

            InetAddress direccionServidor = InetAddress.getByName(SERVIDOR_IP);

            while (true) {
                System.out.println("Ingrese el término de búsqueda:");
                String termino = sc.nextLine();

                System.out.println("Ingrese el código del idioma (1: Español, 2: Inglés):");
                int idioma = Integer.parseInt(sc.nextLine());

        		System.out.println("Tipo de respuesta: (1)una / (2)todas");
				String tipoRespuesta = sc.nextLine();
				if (tipoRespuesta.equalsIgnoreCase("1")) {
					tipoRespuesta = "una";
				} else if (tipoRespuesta.equalsIgnoreCase("2")) {
					tipoRespuesta = "todas";
				}


                String mensaje = termino + ";" + idioma + ";" + tipoRespuesta;

                // Enviar la solicitud al servidor
                byte[] buffer = mensaje.getBytes();
                DatagramPacket datagramaEnvio = new DatagramPacket(buffer, buffer.length, direccionServidor, PUERTO);
                socketCliente.send(datagramaEnvio);

                // Recibir la respuesta del servidor
                byte[] bufferRespuesta = new byte[TAM_BUFFER];
                DatagramPacket datagramaRespuesta = new DatagramPacket(bufferRespuesta, bufferRespuesta.length);
                socketCliente.receive(datagramaRespuesta);

                // Mostrar la respuesta recibida
                String respuesta = new String(datagramaRespuesta.getData(), 0, datagramaRespuesta.getLength());
                System.out.println("Respuesta del servidor: " + respuesta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}