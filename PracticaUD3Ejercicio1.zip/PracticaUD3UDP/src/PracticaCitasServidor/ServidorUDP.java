package PracticaCitasServidor;
import java.net.*;
import java.util.ArrayList;
import java.util.Random;

public class ServidorUDP {
    private static final int PUERTO = 22222;
    private static final int TAM_BUFFER = 1024;

    public static void main(String[] args) {
        DatagramSocket socketServidor = null;
        try {

            socketServidor = new DatagramSocket(PUERTO);
            System.out.println("Servidor UDP iniciado. Esperando datagramas...");

      
            ArrayList<Cita> citas = new ArrayList<>();
            // Agregar citas
            agregarCitas(citas);

            // Bucle infinito para escuchar datagramas
            while (true) {
                byte[] buffer = new byte[TAM_BUFFER];
                DatagramPacket datagramaRecibido = new DatagramPacket(buffer, buffer.length);

           
                socketServidor.receive(datagramaRecibido);

               
                String mensajeRecibido = new String(datagramaRecibido.getData(), 0, datagramaRecibido.getLength());
                String respuesta = procesarSolicitud(mensajeRecibido, citas);


                byte[] bufferRespuesta = respuesta.getBytes();
                DatagramPacket datagramaRespuesta = new DatagramPacket(bufferRespuesta, bufferRespuesta.length,
                        datagramaRecibido.getAddress(), datagramaRecibido.getPort());

           
                socketServidor.send(datagramaRespuesta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (socketServidor != null) {
                socketServidor.close();
            }
        }
    }

    private static void agregarCitas(ArrayList<Cita> citas) {
        // Agregar citas al ArrayList
        citas.add(new Cita("Groucho Marx", "¿A quién va usted a creer, a mí o a sus propios ojos?", 1));
        citas.add(new Cita("Groucho Marx", "No puedo decir que no estoy en desacuerdo contigo", 1));
        citas.add(new Cita("Groucho Marx",
                "Those are my principles, and if you don't like them... well, I have others.", 2));
        citas.add(new Cita("Groucho Marx", "I refuse to join any club that would have me as a member.", 2));
        citas.add(new Cita("Benjamin Franklin", "Well done is better than well said", 2));
        citas.add(new Cita("Mark Twain", "Don't dream your life, live your dream", 2));
        citas.add(new Cita("", "The harder I work, the luckier I get", 2));
        citas.add(new Cita("Octavio Paz", "Aprender a sonreír es aprender a ser libres", 1));
        citas.add(new Cita("Hemingway", "Se necesitan dos años para aprender a hablar y sesenta para aprender a callar", 1));
        citas.add(new Cita("Che Guevara", "Seamos realistas y hagamos lo imposible.", 1));
    }

    private static String procesarSolicitud(String mensaje, ArrayList<Cita> citas) {
        // Procesar la solicitud y generar la respuesta
        String[] partes = mensaje.split(";");
        if (partes.length == 3) {
            String termino = partes[0];
            int idioma = Integer.parseInt(partes[1]);
            String tipoRespuesta = partes[2];
            StringBuilder respuesta = new StringBuilder();

            for (Cita cita : citas) {
                if (cita.getIdioma() == idioma &&
                    (cita.getAutor().toLowerCase().contains(termino.toLowerCase()) ||
                     cita.getCita().toLowerCase().contains(termino.toLowerCase()))) {
                    respuesta.append(cita.toString()).append("\n");
                }
            }
            
            // Verificar el tipo de respuesta
            if (tipoRespuesta.equalsIgnoreCase("todas")) {
                return respuesta.toString();
            } else if (tipoRespuesta.equalsIgnoreCase("una") && !respuesta.toString().isEmpty()) {
                // Si hay citas que coinciden, se elige una al azar
                Random r = new Random();
                String[] citasArray = respuesta.toString().split("\n");
                return citasArray[r.nextInt(citasArray.length)];
            } else {
                return "Error: No se encontraron citas que coincidan con la solicitud";
            }
        } else {
            return "Error: La solicitud debe contener tres partes separadas por ';' (termino;idioma;tipoRespuesta)";
        }
    }

}