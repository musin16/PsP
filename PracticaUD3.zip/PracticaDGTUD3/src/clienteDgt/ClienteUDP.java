package clienteDgt;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import servidorDgt.Registro;

public class ClienteUDP {
	private static final String SERVIDOR_IP = "localhost";
	private static final int PUERTO = 12345;
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try (DatagramSocket socketCliente = new DatagramSocket()) {
			InetAddress direccionServidor = InetAddress.getByName(SERVIDOR_IP);
			int opcion;
			do {
				mostrarMenu();
				System.out.print("Ingrese opción: ");
				opcion = sc.nextInt();

				switch (opcion) {
				case 1:
					enviarRegistro(socketCliente, direccionServidor, generarRegistro());
					break;
				case 2:
					System.out.println("Saliendo...");
					Thread.sleep(1000);
					System.out.println("Salida con exito");
					break;
				default:
					System.out.println("Opción inválida. Inténtelo de nuevo.");
				}
			} while (opcion != 2);

		} catch (IOException e) {
			System.err.println("Error de E/S: " + e.getMessage());
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static void mostrarMenu() {
		System.out.println("Menú:");
		System.out.println("1 - Enviar registro de tráfico");
		System.out.println("2 - Salir");
	}

	private static Registro generarRegistro() {

		System.out.print("Ingrese el ID del dispositivo: ");
		String idDispositivo = sc.nextLine();
		Date time = new Date();
		System.out.print("Ingrese el número de coches (1 o 2): ");
		int numero = sc.nextInt();
		sc.nextLine();
		return new Registro(idDispositivo, time, numero);
	}

	private static void enviarRegistro(DatagramSocket socket, InetAddress direccionServidor, Registro registro)
			throws IOException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String fechaFormateada = dateFormat.format(registro.getTimestamp());
		String mensaje = registro.getIdDispositivo() + " | " + fechaFormateada + " | " + registro.getNumero();
		byte[] buffer = mensaje.getBytes();
		DatagramPacket datagramaEnvio = new DatagramPacket(buffer, buffer.length, direccionServidor, PUERTO);
		socket.send(datagramaEnvio);
		System.out.println("Registro enviado al servidor: " + mensaje);
	}
}
