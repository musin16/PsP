package servidorDgt;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ServidorUDP {
	private static final int PUERTO = 12345;
	private static final int TAMANIO_BUFFER = 1024;
	private static List<Registro> registros = new ArrayList<>();

	public static void main(String[] args) {
		try (DatagramSocket socketServidor = new DatagramSocket(PUERTO)) {
			System.out.println("Servidor UDP iniciado. Esperando mensajes...");

			Registro menuThread = new Registro();
			menuThread.start();

			while (true) {
				byte[] buffer = new byte[TAMANIO_BUFFER];
				DatagramPacket datagramaRecibido = new DatagramPacket(buffer, buffer.length);

				socketServidor.receive(datagramaRecibido);

				String mensajeRecibido = new String(datagramaRecibido.getData(), 0, datagramaRecibido.getLength());
				System.out.println("Mensaje recibido: " + mensajeRecibido);
				// Parsear el mensaje y agregar el registro a la lista
				String[] partes = mensajeRecibido.split(" \\| ");
				if (partes.length == 3) {
					String idDispositivo = partes[0];
					Date timestamp = parsearFecha(partes[1]);
					int numero = Integer.parseInt(partes[2]);
					Registro registro = new Registro(idDispositivo, timestamp, numero);
					registros.add(registro);
				} else {
					System.out.println("Error: Mensaje incorrecto");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Date parsearFecha(String fechaStr) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			return dateFormat.parse(fechaStr);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static int obtenerCochesUltimaHora() {
		Date ahora = new Date();
		long haceUnaHora = ahora.getTime() - 3600 * 1000;

		int totalCoches = 0;
		for (Registro registro : registros) {
			if (registro.getTimestamp().getTime() > haceUnaHora
					&& registro.getTimestamp().getTime() <= ahora.getTime()) {
				totalCoches += registro.getNumero();
			}
		}
		return totalCoches;
	}

	public static int obtenerCochesDiaActual() {
		Date hoy = truncarHora(new Date());

		int totalCoches = 0;
		for (Registro registro : registros) {
			if (registro.getTimestamp().getTime() > hoy.getTime()) {
				totalCoches += registro.getNumero();
			}
		}
		return totalCoches;
	}

	public static int obtenerCochesDiaIndicado(Date fecha) {
		Date inicioDia = truncarHora(fecha);
		Date finDia = new Date(inicioDia.getTime() + 24 * 3600 * 1000 - 1);

		int totalCoches = 0;
		for (Registro registro : registros) {
			if (registro.getTimestamp().getTime() >= inicioDia.getTime()
					&& registro.getTimestamp().getTime() <= finDia.getTime()) {
				totalCoches += registro.getNumero();
			}
		}
		return totalCoches;
	}

	private static Date truncarHora(Date fecha) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return dateFormat.parse(dateFormat.format(fecha));
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

}
