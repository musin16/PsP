package servidorDgt;

import java.util.Date;
import java.util.Scanner;

public class Registro extends Thread {
	private String idDispositivo;
	private Date timestamp;
	private int numero;
	private Scanner sc = new Scanner(System.in);

	public Registro() {
	}

	public Registro(String idDispositivo, Date timestamp, int numero) {
		this.idDispositivo = idDispositivo;
		this.timestamp = timestamp;
		this.numero = numero;
	}

	public String getIdDispositivo() {
		return idDispositivo;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public int getNumero() {
		return numero;
	}

	@Override
	public void run() {

		int opcion;

		while (true) {
			System.out.println("Menú:");
			System.out.println("1 - Mostrar número de coches última hora");
			System.out.println("2 - Mostrar número de coches día actual");
			System.out.println("3 - Mostrar número de coches día indicado");
			System.out.println("4 - Salir");
			System.out.print("Ingrese opción: ");
			opcion = sc.nextInt();

			switch (opcion) {
			case 1:
				System.out.println("Número de coches en la última hora: " + ServidorUDP.obtenerCochesUltimaHora());
				break;
			case 2:
				System.out.println("Número de coches en el día actual: " + ServidorUDP.obtenerCochesDiaActual());
				break;
			case 3:
				System.out.println("Ingrese la fecha (formato: yyyy-MM-dd): ");
				String fechaStr = sc.next();
				Date fecha = ServidorUDP.parsearFecha(fechaStr + "T00:00:00");
				System.out.println(
						"Número de coches en la fecha indicada: " + ServidorUDP.obtenerCochesDiaIndicado(fecha));
				break;
			case 4:
				System.out.println("Saliendo...");
				System.exit(0);
				break;
			default:
				System.out.println("Opción inválida. Inténtelo de nuevo.");
			}
		}
	}
}
